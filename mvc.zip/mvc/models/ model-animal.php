<?php
// models/model-animal.php
class Model {
    // Base model methods and properties
}
?>

