<!DOCTYPE html>
<html>
<head>
    <title>Welcome to the Library</title>
</head>
<body>
    <h1>Welcome to the Library Management System</h1>
    <p>This is a place where you can manage your books, check out new titles, and more.</p>
    <ul>
        <li><a href="dashboard.php">View Dashboard</a></li>
        <li><a href="login.php">Login</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</body>
</html>
