<!DOCTYPE html>
<html>
<head>
    <title>404 Not Found</title>
</head>
<body>
    <h1>404 Not Found</h1>
    <p>Oops! The page you are looking for does not exist.</p>
    <p><a href="welcome.php">Return to the home page</a></p>
</body>
</html>
